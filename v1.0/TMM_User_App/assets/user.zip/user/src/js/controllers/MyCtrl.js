tmmApp.controller('MyCtrl',['$scope','$http','$location','$rootScope',function($scope,$http,$location,$rootScope) {
    // $scope.isLogin = false;
    
    $scope.is_organizer = false;

    $http.get(API + '/index.php?r=api/user/view').success(function(data) {

        if (data.status == 0) {
            $rootScope.isLogin = false;
        } else {
            $rootScope.user = data.data;
            $scope.is_organizer = data.data.userInfo.is_organizer == 0 ? false : true;
            $rootScope.isLogin = true;
        }

    });

    // $scope.user = JSON.parse(localStorage.user);

    $scope.toLogin = function() {
        $location.path('login');
    }

    // 退出登录
    // $http.get(API + '/index.php?r=api/login/out').success(function(data) {

    // });

    $scope.goPage = function(link) {

        if ($rootScope.isLogin) {
            $location.path(link);
        } else {
            $location.path('login');
        }

        
    }

}]);