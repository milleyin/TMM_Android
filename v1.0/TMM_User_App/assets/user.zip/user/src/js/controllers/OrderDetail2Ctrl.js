tmmApp.controller('OrderDetail2Ctrl',['$scope','$http','$location','$routeParams','$rootScope','$interval',function($scope,$http,$location,$routeParams,$rootScope,$interval) {

    $scope.orderinfo = {};
    $scope.isShowCode = false;
    $scope.csrf = '';
    $scope.msg = '等待确认';
    $scope.payFlag = false;

    // 获取订单信息
    $scope.getOrderInfo = function() {
        $http.get(API + '/index.php?r=api/order/view&id=' + $routeParams.id).success(function(data) {
            console.log(data);
            $scope.orderinfo = data.data;
            if ($scope.orderinfo.status.order_status.value == 1) {
                $interval.cancel(timer);
                $scope.msg = '确认';
                $scope.payFlag = true;
            }
        });
    }

    $scope.getOrderInfo();

    // 显示二维码
    $scope.showCode = function(link) {
        $http.get(link).success(function(data) {
            var $code = $('<div id="code"></div>');
            $('body').append($code);
            $scope.isShowCode = true;
            var qrcode = new QRCode($code.get(0), {
                width : 200,//设置宽高
                height : 200,
            });
    
            qrcode.makeCode(data.data.barcode.value);
            
        });
    }

    // 删除二维码
    $scope.deleteCode = function() {
        $scope.isShowCode = false;
        $('#code').remove();
    }
    
}]);